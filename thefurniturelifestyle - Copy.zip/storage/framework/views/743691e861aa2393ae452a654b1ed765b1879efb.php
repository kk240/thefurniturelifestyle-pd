
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">


<head>
<meta charset="utf-8">
<title>Decorators - Design Studio HTML Template | Homepage</title>
<!-- Stylesheets -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title><?php echo e(config('app.name', 'Laravel')); ?></title>
<script src="<?php echo e(asset('/public/js/app.js')); ?>" defer></script>
<link rel="dns-prefetch" href="//fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
<link href="<?php echo e(asset('/public/css/bootstrap.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/public/css/revolution-slider.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/public/css/style.css')); ?>" rel="stylesheet">
<link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon">
<link rel="icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link href="<?php echo e(asset('/public/css/responsive.css')); ?>" rel="stylesheet">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>
    <div id="app">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="fa fa-long-arrow-up"></span></div>


<script src="<?php echo e(asset('/public/js/jquery.js')); ?>"></script> 
<script src="<?php echo e(asset('/public/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('/public/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(asset('/public/js/revolution.min.js')); ?>"></script>
<script src="<?php echo e(asset('/public/js/jquery.fancybox.pack.js')); ?>"></script>
<script src="<?php echo e(asset('/public/js/jquery.fancybox-media.js')); ?>"></script>
<script src="<?php echo e(asset('/public/js/isotope.js')); ?>"></script>
<script src="<?php echo e(asset('/public/js/owl.js')); ?>"></script>
<script src="<?php echo e(asset('/public/js/wow.js')); ?>"></script>
<script src="<?php echo e(asset('/public/js/script.js')); ?>"></script>
</body>


</html><?php /**PATH C:\xampp\htdocs\theFurnitureLifestyle\resources\views/layouts/app.blade.php ENDPATH**/ ?>