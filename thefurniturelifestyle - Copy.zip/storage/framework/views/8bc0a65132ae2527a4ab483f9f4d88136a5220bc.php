 <footer class="main-footer" style="background-image:url(images/background/footer-bg.jpg);">
    	<div class="auto-container">
        
            <!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	<!--Big Column-->
                	<div class="big-column col-md-6 col-sm-12 col-xs-12">
                    	<div class="row clearfix">
                            
                            <!--Footer Column-->
                        	<div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            	<div class="footer-widget about-widget">
                                	<div class="footer-logo"><figure><a href="index-2.html"><img src="<?php echo e(asset('/public/images/logo-4.png')); ?>" alt=""></a></figure></div>
                                    <div class="widget-content">
                                    	<div class="text">Must explain too you all this mistaken idea off denouncing pleasure and well praising pain was born and I will gives you complete accounts systems must explain to idea of denouncing.</div>
                                        <ul class="contact-info">
                                        	<li><span class="icon fa fa-map-marker"></span>Dangat Estate, Warje, Pune</li>
                                            <li><span class="icon fa fa-phone"></span><a href="tel:7875303545">+91 787-530-3545</a></li>
                                            <li><span class="icon fa fa-envelope-o"></span>thefurniturelifestyle@gmail.com</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                        	<div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            	<div class="footer-widget tags-widget">
                                	<h2>Popular Tags</h2>
                                    <div class="widget-content">
                                    	<ul class="tags-list">
                                        	<li><a href="#">Designs</a></li>
                                            <li><a href="#">Tips</a></li>
                                            <li><a href="#">Interior</a></li>
                                            <li><a href="#">Doors</a></li>
                                            <li><a href="#">Curtains</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="footer-widget gallery-widget">
                                	<h2>Recent Works</h2>
                                    <div class="gallery-widget-carousel">
                                    	<div class="item"><figure class="post-thumb"><img src="<?php echo e(asset('/public/images/gallery/thumb-1.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure></div>
                                        <div class="item"><figure class="post-thumb"><img src="<?php echo e(asset('/public/images/gallery/thumb-2.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure></div>
                                        <div class="item"><figure class="post-thumb"><img src="<?php echo e(asset('/public/images/gallery/thumb-3.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure></div>
                                        <div class="item"><figure class="post-thumb"><img src="<?php echo e(asset('/public/images/gallery/thumb-4.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure></div>
                                        <div class="item"><figure class="post-thumb"><img src="<?php echo e(asset('/public/images/gallery/thumb-1.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure></div>
                                        <div class="item"><figure class="post-thumb"><img src="<?php echo e(asset('/public/images/gallery/thumb-2.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure></div>
                                        <div class="item"><figure class="post-thumb"><img src="<?php echo e(asset('/public/images/gallery/thumb-3.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure></div>
                                        <div class="item"><figure class="post-thumb"><img src="<?php echo e(asset('/public/images/gallery/thumb-4.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure></div>
                                        <div class="item"><figure class="post-thumb"><img src="<?php echo e(asset('/public/images/gallery/thumb-1.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure></div>
                                        <div class="item"><figure class="post-thumb"><img src="<?php echo e(asset('/public/images/gallery/thumb-2.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure></div>
                                        <div class="item"><figure class="post-thumb"><img src="<?php echo e(asset('/public/images/gallery/thumb-3.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure></div>
                                        <div class="item"><figure class="post-thumb"><img src="<?php echo e(asset('/public/images/gallery/thumb-4.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure></div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                    <!--Big Column-->
                	<div class="big-column col-md-6 col-sm-12 col-xs-12">
                    	<div class="row clearfix">
                            
                            <!--Footer Column-->
                        	<div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            	<div class="footer-widget posts-widget">
                                	<h2>Recent News</h2>
                                    <div class="widget-content">
                                    	<div class="posts">
                                            <div class="post">
                                                <figure class="post-thumb"><img src="<?php echo e(asset('/public/images/resource/post-thumb-1.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="flaticon-plus-1"></span></a></figure>
                                                <div class="desc-text"><a href="#">How mistakens denoncings pleasure and complete.</a></div>
                                                <div class="time"><span class="fa fa-clock-o"></span> Oct 03, 2015</div>
                                            </div>
                                            <div class="post">
                                                <figure class="post-thumb"><img src="<?php echo e(asset('/public/images/resource/post-thumb-2.jpg')); ?>" alt=""><a href="#" class="overlay-link"><span class="flaticon-plus-1"></span></a></figure>
                                                <div class="desc-text"><a href="#">Pleasure praising pains was, expound actual teaching.</a></div>
                                                <div class="time"><span class="fa fa-clock-o"></span> Aug 21, 2015</div>
                                            </div>
                                        </div>
                                        <a class="view-more theme-btn" href="#">Read More <span class="fa fa-caret-right"></span></a>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                        	<div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            	<div class="footer-widget contact-widget">
                                	<h2>Send Us Message</h2>
                                    <div class="widget-content">
                                        <div class="newsletter-form">
                                            <form method="post" action="#">
                                                <div class="form-group">
                                                    <input type="text" name="name" value="" placeholder="Name" required>
                                                </div>
                                                <div class="form-group">
                                                    <input type="email" name="email" value="" placeholder="Email *" required>
                                                </div>
                                                <div class="form-group">
                                                    <textarea name="message" placeholder="Message *" required></textarea>
                                                </div>
                                                <button type="submit" class="theme-btn btn-style-two">Send us</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                 </div>
             </div>
        
        </div>
        
        <!--Footer Bottom-->
         <div class="footer-bottom">
         	<div class="auto-container">
            	<div class="clearfix">
                    <div class="pull-right">
                    	<ul class="footer-nav">
                        	<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li><a href="">About</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer><?php /**PATH C:\xampp\htdocs\thefurniturelifestyle.com\resources\views/layouts/footer.blade.php ENDPATH**/ ?>